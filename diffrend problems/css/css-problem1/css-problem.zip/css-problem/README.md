CSS-Centering
=============

Center the text in the button. As reference see the png image in this repo.
Do not use calc.
Button and font sizes should dynamically adjust according to the browser window size.
